def foo():
    return 'bar'
